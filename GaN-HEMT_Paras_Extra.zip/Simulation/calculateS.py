import os
import re
import numpy as np
import subprocess
import json
import time
from Simulation import data_process

netlist = r"C:\Users\87515\MyFirstWorkspace_wrk\netlist2.txt"
script = r"C:\Users\87515\MyFirstWorkspace_wrk\script2.bat"

N = 19
def calculate_S_mod(params):
    with open(netlist, 'r') as file:
        content = file.read()

    # 替换参数值
    for parameter, new_value in params.items():
        if parameter[0] == "C":
            new_value = str(new_value) + " fF"
        if parameter[0] == "L":
            new_value = str(new_value) + " pH"
        content = re.sub(f'{parameter}=.*', f'{parameter}={new_value}', content)

    # 将修改后的内容写回文件
    with open(netlist, 'w') as file:
        file.write(content)

    script_dir = os.path.dirname(script)
    #start_time = time.time()
    subprocess.run(["cmd", "/c", script], cwd=script_dir, stdout=subprocess.DEVNULL)
    #end_time = time.time()
    #execution_time = end_time - start_time
    return np.array(data_process.get_S(20,1))

def calculate_loss(params,idx):
    with open(r'C:\Users\87515\Documents\PyProject\GaN-HEMT_Paras_Extra\Simulation\Data\meas{}.json'.format(idx), 'r') as f:
        S_meas = np.array(json.load(f))
    S_mod = calculate_S_mod(params)
    l1 = 0
    for i in range(4):
        root = 0
        l2 = 0
        for j in range(N):
            r = (S_mod[i][j][0]-S_meas[i][j][0])**2
            im = (S_mod[i][j][1]-S_meas[i][j][1])**2
            root = max((S_meas[i][j][0]+S_meas[i][j][1])**2,root)
            l2 += (r+im)
        l1 += l2/root

    return np.sqrt(l1)/4/N

