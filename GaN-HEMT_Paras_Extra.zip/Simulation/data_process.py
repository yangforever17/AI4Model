import os
import json
import numpy as np
from smithplot import SmithAxes
from matplotlib import rcParams
import matplotlib.pyplot as pp
rcParams.update({"legend.numpoints": 3})
rcParams["font.family"] = "Times New Roman"

data = [[], [], [], []]

def get_S(step = 1,fp = 1):
    datas = [[], [], [], []]
    if fp == 1:
        file = r"C:\Users\87515\MyFirstWorkspace_wrk\s2.txt"
    elif fp==0:
        file = r"C:\Users\87515\MyFirstWorkspace_wrk\s.txt"
    else:
        file = r"C:\Users\87515\MyFirstWorkspace_wrk\snew.txt"

    with open(file, 'r') as file:
        lines = file.readlines()

    # 查找起始行索引
    start_index = 0
    for i, line in enumerate(lines):
        if line.strip() == 'Values:':
            start_index = i + 1
            break

    # 提取数据行
    data_lines = lines[start_index:]

    for i in range(len(data_lines) // (8*step)):
        for j in range(4):
            line = data_lines[i * 8 * step + j + 1]
            line = line.strip()
            if line:
                values = line.split(',')
                values = [float(value) for value in values]
                datas[j].append(values)
    return datas

if __name__ == "__main__":
    # 转换为NumPy数组
    data = np.array(get_S(fp=3))
    S11 = data[0]
    S12 = data[1]
    S21 = data[2]
    S22 = data[3]
    # 提取第一列和第二列数据
    real = data[:,:, 0]
    imag = data[:,:, 1]

    # 计算mag和ang
    mag = np.sqrt(real**2 + imag**2)
    ang = np.arctan2(imag, real) * 180 / np.pi

    # 将结果存储在新的数组中
    cdata = [[],[],[],[]]
    for i in range(4):
        cdata[i] = np.column_stack((mag[i], ang[i]))

    #print("转换后的结果：")
    freq = np.arange(0.1,40.1,0.1)
    #cdata  = data[:, 0] + data[:, 1] * 1j
    print(S11.shape)
    S11s = S11[:,0] + S11[:,1] * 1j
    S12 = np.array(S12)
    S12s = S12[:,0] + S12[:,1] * 1j
    S21 = np.array(S21)
    S21s = S21[:,0] + S21[:,1] * 1j
    S22 = np.array(S22)
    S22s = S22[:,0] + S22[:,1] * 1j

    S_meas = []
    with open('meas111.json', 'r') as f:
        # Read the data from the file as json
        So = np.array(json.load(f))

    with open('meas11.json', 'r') as f:
        # Read the data from the file as json
        Sm = np.array(json.load(f))


    pp.figure(figsize=(6, 6),dpi=300,facecolor="w")
    ax = pp.subplot(1, 1, 1, projection='smith')

    pp.plot(-(So[0,:,0]+ So[0,:,1] * 1j),datatype=SmithAxes.S_PARAMETER,linestyle = '--',label="Before improvement",marker=None,c="black")
    pp.plot((So[1, :, 0] + So[1, :, 1] * 1j), datatype=SmithAxes.S_PARAMETER,marker=None,linestyle = '--',c="black")
    pp.plot(1.5*(So[2, :, 0] + So[2, :, 1] *1j),datatype=SmithAxes.S_PARAMETER,marker=None,linestyle = '--',c="black")
    pp.plot((So[3, :, 0] + So[3, :, 1] * 1j),datatype=SmithAxes.S_PARAMETER,marker=None,linestyle = '--',c="black")
    pp.plot(-(Sm[0,:,0]+ Sm[0,:,1] * 1j),datatype=SmithAxes.S_PARAMETER,c="black",marker=None,label="After improvement")
    pp.plot((Sm[1, :, 0] + Sm[1, :, 1] * 1j), datatype=SmithAxes.S_PARAMETER,marker=None,c="black")
    pp.plot(1.5*(Sm[2, :, 0] + Sm[2, :, 1] *1j),datatype=SmithAxes.S_PARAMETER,marker=None,c="black")
    pp.plot((Sm[3, :, 0] + Sm[3, :, 1] * 1j),datatype=SmithAxes.S_PARAMETER,marker=None,c="black")
    pp.plot(-(S_meas[0,:,0]+ S_meas[0,:,1] * 1j),"o",label="-S11", markersize=8)
    pp.plot((S_meas[1, :, 0] + S_meas[1, :, 1] * 1j), "o",label="S12", markersize=8)
    pp.plot(1.5*(S_meas[2, :, 0] + S_meas[2, :, 1] *1j), "o",label="1.5*S21", markersize=8)
    pp.plot((S_meas[3, :, 0] + S_meas[3, :, 1] * 1j), "o",label="S22", markersize=8)

    pp.legend(fontsize=8,loc="lower left")
    title =  ['2*50 um','8*125 um','8*250 um','16*250 um']
    title = title[0]
    pp.title(title)
    title = title.replace("*","-")
    title += 'S.pdf'
    pp.savefig(title, dpi=250, bbox_inches='tight')
    pp.show()


