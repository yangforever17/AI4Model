import numpy as np
import json

file = r"C:\Users\87515\MyFirstWorkspace_wrk\snew.txt"

S11 = []
S12 = []
S21 = []
S22 = []
data = [S11,S12,S21,S22]

with open(file, 'r') as file:
    lines = file.readlines()

# 查找起始行索引
start_index = 0
for i, line in enumerate(lines):
    if line.strip() == 'Values:':
        start_index = i + 1
        break

# 提取数据行
data_lines = lines[start_index:]

#采样 19-160
kk = 24
for i in range(int(len(data_lines)//kk/3.7/2)):
    for j in range(4):
        line = data_lines[i*kk+j+1]
        line = line.strip()
        if line:
            values = line.split(',')
            values = [round(float(value),4) for value in values]
            data[j].append(values)

with open('meas333.json', 'w') as f:
    # Write the data to the file as json
    json.dump(data, f)

'''
with open('meas.json', 'r') as f:
    # Read the data from the file as json
    data = json.load(f)
'''