import numpy as np
from Model.dknet.models import NNRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern,RBF
from scipy.stats import norm
from pyDOE import lhs


class Bayes_Optimization:
    def __init__(self, objfun, modeltype,layers,opt, n_initial_points, trial_time, paras, verbose = True,x=None, y=None,step_nums=100, sigma=0.1,iniparas=None):
        """
        objun:目标函数
        x:自变量
        y:因变量
        opt: 优化器
        loss:模型评价所用到的损失函数
        sigma:高斯核中的带宽
        trial_time:实验次数
        paras:要调的模型超参，仅支持连续类型变量；value格式为：[最小值，最大值]
        step_nums:每个参数根据上下届切成多少份；对应optuna中suggsest_float中的step，不过step是步长，此处是总步数。
        本来应该对每个超参设一个step_nums,此处由于是作学习用，犯懒一下做一个全局设置
        n_initial_points:初始化的点数量，对应optuna中Sampler的n_initial_points。
        """
        self.paras = paras
        self.modeltype = modeltype
        self.para_keys = paras.keys()
        self.sigma = sigma
        self.x = x
        self.y = y
        self.step_nums = step_nums
        self.n_initial_points = n_initial_points
        #self.loss =
        self.trial_time = trial_time
        self.opt = opt
        self.layers = layers
        self.objfun = objfun
        self.verbose = verbose
        self.iniparas = iniparas
    def kernel(self, x1, x2):
        """
        核函数，可用于求协方差矩阵
        此处使用高斯核函数
        此处的sigma是核函数的一个参数，用来调整带宽
        """
        return np.exp(-(np.linalg.norm(x1 - x2) ** 2) / (2 * self.sigma ** 2))

    def converce(self,x):
        parameters = {
            "Rg": x[0], "Rd": x[1], "Rs": x[2], "Gds": x[3],
            "Lg": x[4], "Ld": x[5], "Ls": x[6],
            "Cgp": x[7], "Cdp": x[8], "Cgd": x[9], "Cgs": x[10], "Cds": x[11]
        }
        return parameters

    def lhs(self,n,d):
        # 定义参数空间的维度和采样点的数量
        num_samples = n  # 采样点的数量
        num_dimensions = d  # 参数空间的维度
        # 生成拉丁超立方采样
        latin_hypercube_samples = lhs(num_dimensions, samples=num_samples, criterion='maximin')
        upper = [value[1] for value in self.paras.values()]
        lower = [value[0] for value in self.paras.values()]
        upper = np.array(upper)
        lower = np.array(lower)
        scaled_samples = latin_hypercube_samples * (upper - lower) + lower

        return  scaled_samples
    def Gaussian_Progress_Regression(self, x, x_dot, y, sigma_n=0.05):
        """
        x:已知的超参
        x_dot:待选超参
        y:已知超参所训练出来的模型对应的损失函数
        sigma:高斯核带宽
        sigma_n:噪声的
        注意此处的x和y不再是数据中的自变量与因变量
        """
        # 假设f的均值为0，此处计算其方差
        K = [self.kernel(i, j) for i in x for j in x]
        K_dot = [self.kernel(i, j) for i in x_dot for j in x]
        K_dot2 = [self.kernel(i, j) for i in x_dot for j in x_dot]

        n = x.shape[0]
        n_dot = x_dot.shape[0]
        K = np.array(K).reshape((n, n))
        K_dot = np.array(K_dot).reshape((n_dot, n))
        K_dot2 = np.array(K_dot2).reshape((n_dot, n_dot))

        n = K.shape[0]
        res_mu = np.dot(K_dot, np.dot(np.linalg.inv(K + (sigma_n ** 2) * np.eye(n)), y))
        res_sigma = K_dot2 - np.dot(K_dot, np.dot(np.linalg.inv(K + (sigma_n ** 2) * np.eye(n)), K_dot.T))
        std = np.sqrt(res_sigma.diagonal())
        return res_mu, std

    def DNGP(self, x, x_dot, y):
        gp = NNRegressor(self.layers, opt=self.opt, batch_size=x.shape[0], maxiter=100, gp=True, verbose=False)
        gp.fit(x, y)
        #mu, sigma = gp.predict(x_dot)
        mu, sigma = gp.predicts(x, y,x_dot)
        return mu,sigma

    def ucb_acquisition_function(self,mean, std, iteration, kappa=2.576):
        """
        计算UCB采集函数的值
        参数：
        mean: 模型预测的均值
        std: 模型预测的标准差
        iteration: 当前迭代次数
        kappa: UCB的探索参数
        返回值：
        ucb_values: UCB采集函数的值
        """
        mean = mean.ravel()
        std = std.ravel()
        ucb_values = mean + kappa * std
        return ucb_values

    def acquisition(self, mu, std, f_dot):
        """
        x:超参的参数空间
        此处的采集函数为Expected improvement
        希望找到max(0,f'-f(x));f'=min(f)（已知最小值） 也就是比f'越小越好
        (在论文中是越大越好，但是我们这里的f是损失函数，默认是要去minimize的)
        https://www.cnblogs.com/marsggbo/p/9866764.html
        """
        mu = mu.ravel()
        std =std.ravel()
        Z = np.maximum(f_dot - mu, 0)
        Z = Z / std
        delta = f_dot - mu
        EI = delta * norm.cdf(Z) + std * norm.pdf(Z)
        return EI

    def optimize(self):
        # 随机初始化n_initial_points组超参Parameters作为初始点
        initial_flag = True
        x = None
        y = None
        for cs in range(self.n_initial_points):
            if self.iniparas != None:
                paras = self.iniparas
            else:
                paras = self.paras
            res_para = {}
            for i in self.para_keys:
                res_para[i] = np.round(np.random.uniform(paras[i][0], paras[i][1]),2)
            #print(res_para)
            tmp_y = self.objfun(res_para)
            #print(cs," : " ,tmp_y)
            tmp_x = np.array([res_para[i] for i in self.para_keys])
            if initial_flag:
                x = np.array([tmp_x])
                y = np.array([tmp_y])
                initial_flag = False
            else:
                x = np.append(x, np.array([tmp_x]), axis=0)
                y = np.append(y, np.array([tmp_y]), axis=0)
        y = y.reshape(-1,1)
        #y = y.reshape(10,152)
        #print(y.shape)
        print("Initial finished")
        # 初始化x_dot
        #x_dot = []
        '''
        for j in range(self.step_nums):
            tmp_x_dot = []
            for i in self.para_keys:
                tmp_x_dot.append((self.paras[i][1]-self.paras[i][0])/self.step_nums*j+self.paras[i][0])
            x_dot.append(tmp_x_dot)
        '''
        upper = [value[1] for value in self.paras.values()]
        lower = [value[0] for value in self.paras.values()]
        upper = np.array(upper)
        lower = np.array(lower)
        #x_dot = self.lhs(10000,len(self.paras))
        #x_dot = np.array(x_dot)

        gp = GaussianProcessRegressor(
            kernel=RBF(),
            alpha=1e-6,
            normalize_y=True,
            n_restarts_optimizer=5,
            random_state=np.random.RandomState(),
        )


        for i in range(self.trial_time):
            x_dot = np.random.RandomState().uniform(lower, upper,
                                                    size=(10000, len(self.paras)))
            x_dot = np.round(x_dot,2)

            if self.modeltype == "DNGP":
                mu, std = self.DNGP(x, x_dot, y)
            else:
                #mu, std = self.Gaussian_Progress_Regression(x, x_dot, y)
                gp.fit(x,y)
                mu, std = gp.predict(x_dot,return_std=True)
            #EI = self.acquisition(mu, std, y.min())
            ucb = self.ucb_acquisition_function(mu,std,i+1)
            #print("EI: ",np.argmax(EI))
            x_new = x_dot[np.argmin(ucb)]
            y_new = self.objfun(self.converce(x_new.ravel())).reshape(-1)
            x = np.append(x, np.array([x_new]), axis=0)
            y = np.append(y, np.array([y_new]), axis=0)
            if self.verbose:
                strr = "trial " + str(i + 1) + ": " + str(int(100.0 * float(i + 1) / self.trial_time)) + " %. Loss: " + str(y_new)
                print(strr)
        #print(len(l_new),len(x))
        return x, y