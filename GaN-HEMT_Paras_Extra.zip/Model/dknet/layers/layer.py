import numpy

class Layer:
	dtype=numpy.float64
	def set_inp(self,n_inp):
		self.n_inp=n_inp