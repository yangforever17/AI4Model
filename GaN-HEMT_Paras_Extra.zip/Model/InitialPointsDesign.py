import numpy as np
import GPy
import random
import matplotlib.pyplot as plt

# 创建高斯过程回归模型
kernel = GPy.kern.RBF(input_dim=4,variance=1.0, lengthscale=1.0)  # 使用RBF核函数


from Model import scaling_effect
from sklearn.preprocessing import StandardScaler


def model(idx):
    datax, datay = scaling_effect.gendata(index=idx-2)
    #datay = datay[:,[idx-2]]
    scaler = StandardScaler()

    # 对datax进行标准化
    datax_scaled = scaler.fit_transform(datax)

    # 对datay进行标准化
    datay_scaled = scaler.fit_transform(datay)
    tasktrainx = []
    tasktrainy = []
    tasktestx = []
    tasktesty = []
    for i in range(len(datax)):
        if datax[i][0] == 0 or datax[i][1] == 0:
            tasktestx.append(datax_scaled[i])
            tasktesty.append(datay_scaled[i])
            continue
        else:
            tasktrainx.append(datax_scaled[i])
            tasktrainy.append(datay_scaled[i])

    num_new_data = 20

    tasktrainys = []
    tasktrainxs = []

    #数据扩充
    #由于实际的数据不够多，这里用random来生成做演示
    #正常需要实际的数据，每个size-10组
    for i in range(6):
        new_datax = []
        new_datay = []
        for _ in range(num_new_data):

            multiplier1 = random.uniform(0.9, 1.1)
            multiplier2 = random.uniform(0.9, 1.1)
            # 对原始数据进行乘法操作，生成新数据
            new_datax.append([x*multiplier1 for x in tasktrainx[i]])
            new_datay.append([y*multiplier2 for y in tasktrainy[i]])

        # 将原始数据和新数据合并
        tasktrainxs = tasktrainxs + new_datax+[tasktrainx[i]]
        tasktrainys = tasktrainys + new_datay+[tasktrainy[i]]


    datax = tasktrainxs
    datay = tasktrainys
    tasktestxs = tasktestx[:3]
    tasktestys = tasktesty[:3]
    # %%
    # 假设datax和datay是原始数据
    # 将datax和datay转换为NumPy数组
    datax = np.array(datax)
    datay = np.array(datay)
    testxs = np.array(tasktestxs)
    testys = np.array(tasktestys)
    # 创建高斯过程回归模型
    # 训练模型
    model = GPy.models.GPRegression(datax, datay, kernel)
    model.optimize()
    predictions,cov = model.predict(testxs)
    pred = scaler.inverse_transform(predictions)
    cov = scaler.inverse_transform(cov)
    testy = scaler.inverse_transform(tasktestys)
    testx = scaler.inverse_transform(testxs)
    return pred,cov,testy

# idx为需要得到size的编号
# 目前仅能得到"Rg","Rs","Rd","Ls","Ld","Lg","Cgp","Cdp"寄生的部分
def GPtonewParas(idx):
    r = []
    paras = []
    covs = []
    for i in range(2,10):
        pred,cov,testy = model(i)
        #print("####{}####".format(i-2))
        paras.append(pred[idx][0])
        covs.append(cov[idx])
        #print(cov)
        r.append(np.average(abs(pred - testy) / testy))
        #print((pred - testy) / testy)
    #print(paras)
    #print(covs)
    #print(np.average(r))
    return paras,covs