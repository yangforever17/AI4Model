from  Model import scaling_effect

#source tasks
Rg = [2.32,0.59,1.55,0.73]
Rs = [6.4,0.73,0.45,0.25]
Rd = [7.89,2.22,0.99,0.56]
Ls = [2.23,1.77,2.65,4.53]
Ld = [42.4,54.4,69.6,97.1]
Lg = [48.8,66.6,76.6,119]
Cgp = [26.4,251,131,234]
Cdp = [27.6,206,84,133]
Cgd = [24.5,282,498,1013]
Cgs = [8.65,302,484,960]
Cds = [12.2,133,388,834]
Ggsf = [0.01,0.49,0.82,2.09]
Ggsf = [1/i*1000 for i in Ggsf]


paras = ["Rg","Rs","Rd","Ls","Ld","Lg","Cgp","Cdp","Cgd","Cgs","Cds","Ggsf"]

#common way: just min&&max
def lb():
    return [min(Rg), min(Rs), min(Rd), min(Ls), min(Ld), min(Lg), min(Cgp), min(Cdp), min(Cgd), min(Cgs),
            min(Cds), min(Ggsf)]

def ub():
    return [max(Rg), max(Rs), max(Rd), max(Ls), max(Ld), max(Lg), max(Cgp), max(Cdp), max(Cgd), max(Cgs),
            max(Cds), max(Ggsf)]

#other way: when your data is small
def trans(idx):
    lb = []
    ub = []
    for i in range(len(paras)-1):
        A, B= scaling_effect.fitSC(eval(paras[i]))
        minn = 1000000
        maxn = 0
        for j in range(4):
            value = eval(paras[i])[j]
            new = scaling_effect.getnewpara(idx,j,value,A,B)
            minn = min(minn,new)
            maxn = max(maxn,new)
        lb.append(minn)
        ub.append(maxn)
    return lb,ub
