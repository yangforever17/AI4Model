import numpy as np
import sympy as sp
from scipy.optimize import curve_fit

# 定义符号变量
n1,n2,n3,n4 = sp.symbols('n1 n2 n3 n4')

# source data
fingers = [1,6,5,10] #
gatewidth = [0.1,1,2,4] # mm
Rg = [2.32,0.59,1.55,0.73]
Rs = [6.4,0.73,0.45,0.25]
Rd = [7.89,2.22,0.99,0.56]
Lg = [48.8,66.6,76.6,119]
Ls = [2.23,1.77,2.65,4.53]
Ld = [42.4,54.4,69.6,97.1]
Cgp = [26.4,251,131,234]
Cdp = [27.6,206,84,133]
Cgd = [24.5,282,498,1013]
Cgs = [8.65,302,484,960]
Cds = [12.2,133,388,834]
Ggsf = [0.01,0.49,0.82,2.09]
Ggsf = [1/i*1000 for i in Ggsf]


paras = ["Rg","Rs","Rd","Ls","Ld","Lg","Cgp","Cdp","Cgd","Cgs","Cds","Ggsf"]

#生成数据，包含了PGNN中的特征工程
def gendata(index):
    datax = []
    datay = []
    A,B = fitSC(eval(paras[index]))
    for i in range(4):
        for j in range(4):
            if i==j:
                continue
            #datax.append([i,j,Rg[i],Rs[i],Rd[i],Ls[i],Ld[i],Lg[i],Cgp[i],Cdp[i]])
            #datay.append([Rg[j], Rs[j], Rd[j], Ls[j], Ld[j], Lg[j], Cgp[j], Cdp[j]])
            value = eval(paras[index])
            datax.append([i,j,value[i],getnewpara(j,i,value[i],A,B)])
            datay.append([value[j]])
    return np.array(datax),np.array(datay)

def getnewpara(new,old,para,A,B):
    return para* (fingers[new]/fingers[old])**A *(gatewidth[new] / gatewidth[old])**B

def funcs(x,A,B):
    return x[:,0] ** A * x[:,1] ** B


indexs = [[0,1],[1,0],[2,0],[3,0]]
indexs = np.array(indexs)

def fitSC(para):
    x = []
    for i in range(len(indexs)):
        xx = []
        new,old = indexs[i]
        xx.append(para[old]* (fingers[new]/fingers[old]))
        xx.append((gatewidth[new] / gatewidth[old]))
        x.append(xx)
    x = np.array(x)
    popt, pcov = curve_fit(funcs, x, para)

    # popt 包含了拟合得到的系数
    a_fit, b_fit= popt
    return a_fit,b_fit


