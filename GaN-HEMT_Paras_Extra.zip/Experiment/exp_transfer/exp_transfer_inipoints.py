from Model.InitialPointsDesign import GPtonewParas
from Model.BO import Bayes_Optimization
from Model.dknet.layers import Dense,CovMat,Dropout, Scale
from Model.dknet.optimizers import Adam
import matplotlib.pyplot as plt
import  numpy as np
from Simulation import calculateS

origin_pbounds = {
    'Rg': (0, 50),
    'Rs': (0, 50),
    'Rd': (0, 50),
    'Ls': (0, 100),
    'Ld': (0, 100),
    'Lg': (0, 200),
    'Cgp': (0, 1000),
    'Cdp': (0, 1000),
    'Cgd': (280, 285),
    'Cgs': (300, 305),
    'Cds': (130, 135),
    'Ggsf': (2020, 2040)
}

inipara,covs = GPtonewParas(1)
print(inipara)
iniparas = {
    'Rg': (0.5*inipara[0], 1.5*inipara[0]),
    'Rs': (0.5*inipara[1], 1.5*inipara[1]),
    'Rd': (0.5*inipara[2], 1.5*inipara[2]),
    'Ls': (0.5*inipara[3], 1.5*inipara[3]),
    'Ld': (0.5*inipara[4], 1.5*inipara[4]),
    'Lg': (0.5*inipara[5], 1.5*inipara[5]),
    'Cgp': (0.5*inipara[6], 1.5*inipara[6]),
    'Cdp': (0.5*inipara[7], 1.5*inipara[7]),
    'Cgd': (280, 285),
    'Cgs': (300, 305),
    'Cds': (130, 135),
    'Ggsf': (2020, 2040)
}
def obj(paras):
    value = calculateS.calculate_loss(paras, 1)
    return value

layers=[]
layers.append(Dense(6,activation='tanh'))
layers.append(Dropout(0.95))
layers.append(Dense(6))
layers.append(Scale(fixed=True,init_vals=64.0))
layers.append(CovMat(alpha_fixed=False))
opt=Adam(1e-3)

INIDNGP = Bayes_Optimization(objfun=obj,modeltype="DNGP",layers=layers,opt=opt,n_initial_points = 20, trial_time = 180,paras=origin_pbounds,iniparas=iniparas)
chosens,loss = INIDNGP.optimize()


DNGP = Bayes_Optimization(objfun=obj,modeltype="DNGP",layers=layers,opt=opt,n_initial_points = 20, trial_time = 180,paras=origin_pbounds)
chosens,loss2 = DNGP.optimize()

iters = np.arange(1,len(chosens)+1,1)
best_values = []
for i in range(len(chosens)):
    best_values.append(min(loss[:i+1]))
best_values2 = []
for i in range(len(chosens)):
    best_values2.append(min(loss2[:i+1]))

plt.plot(iters,best_values,c="red")
plt.plot(iters,best_values2)
plt.scatter(iters,loss)
plt.xlabel('Iteration')
plt.ylabel('Target Value')
plt.title('optimize comparation')
plt.savefig('iniTL.pdf', dpi=300, bbox_inches='tight',format="pdf")
plt.legend()
plt.show()
