import numpy as np
import matplotlib.pyplot as plt
from Model.dknet.models import NNRegressor
from Model.dknet.layers import Dense,CovMat,Dropout,Parametrize,Scale
from Model.dknet.optimizers import Adam,SciPyMin,SDProp
from sklearn.gaussian_process import GaussianProcessClassifier,GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF,WhiteKernel,Matern,ConstantKernel as C

def f(x): #Target task
    return np.exp(np.sin(x) + x) + 1

def h(x): #Source task
    return np.exp(np.cos(x) + 2*x)

# data
np.random.seed(0)
x_train=np.random.random(size=(70,1))-0.5
h_train = h(x_train)+np.random.normal(0.0,0.01,size=x_train.shape)
y_train= f(x_train)+np.random.normal(0.0,0.01,size=x_train.shape)

# Structure
layers=[]
layers.append(Dense(6,activation='tanh'))
layers.append(Dropout(0.99))
layers.append(Dense(1))
layers.append(Scale(fixed=True,init_vals=64.0))
layers.append(CovMat(alpha_fixed=False))

# optimize
opt=Adam(1e-3)


### kernel tl
gp=NNRegressor(layers,opt=opt,batch_size=x_train.shape[0],maxiter=100,gp=True,verbose=True)
gp.fit(x_train,h_train)
x_test=np.linspace(-0.7,0.7,1000).reshape(-1,1)
mus,stds = gp.predict(x_test)
mu,std=gp.predicts(x_train,y_train,x_test)

### DNGP
gp=NNRegressor(layers,opt=opt,batch_size=x_train.shape[0],maxiter=100,gp=True,verbose=True)
gp.fit(x_train,y_train)
y_pred,stdt=gp.predict(x_test)

### GP
kernel = C(1.0, (1e-3, 1e3)) * RBF(1.0, (1e-2, 1e2))
model = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=0)

model.fit(x_train, y_train)
y_preds, sigma = model.predict(x_test, return_std=True)


plt.plot(x_train,y_train,'.')
plt.plot(x_test,f(x_test)[:,0])
plt.plot(x_test,mu)
plt.plot(x_test,mus)
plt.plot(x_test,y_pred)
plt.plot(x_test,y_preds)
plt.xlabel('X')
plt.ylabel('Y')
plt.fill_between(x_test[:,0],mu[:]-std,mu[:]+std,alpha=0.5)
plt.fill_between(x_test[:,0],y_pred[:,0]-stdt,y_pred[:,0]+stdt,alpha=0.7)

plt.legend(['Training samples', 'True function', 'Transfer',"Source DNGP","DNGP","GP",'Transfer stddev','DNGP stddev'])
plt.savefig('tldemo.pdf', dpi=300, bbox_inches='tight',format="pdf")
plt.show()
