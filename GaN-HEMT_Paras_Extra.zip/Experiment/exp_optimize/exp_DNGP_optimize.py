import numpy as np
import matplotlib.pyplot as plt
from Model.BO import Bayes_Optimization
from Model.dknet.layers import Dense,CovMat,Dropout, Scale
from Model.dknet.optimizers import Adam
from Model import psoOptimize
import random
from deap import creator, base, tools,algorithms
from Simulation import calculateS


def objective_function(Rg,Rs,Rd,Ls,Ld,Lg,Cgp,Cdp,Cgd,Cgs,Cds,Ggsf):
    parameters = {
    "Rg": Rg,"Rd": Rd,"Rs": Rs,"Gds": Ggsf,
    "Lg": Lg,"Ld": Ld,"Ls": Ls,
    "Cgp": Cgp,"Cdp": Cdp,"Cgd": Cgd,"Cgs": Cgs,"Cds": Cds
    }
    value = calculateS.calculate_loss(parameters, 1)
    return value
def obj(paras):
    value = calculateS.calculate_loss(paras, 1)
    return value

def PSO(pbounds):
    lb =  [value[0] for value in pbounds.values()]
    ub =  [value[1] for value in pbounds.values()]
    def obj(x):
        parameters = {
            "Rg": x[0], "Rd": x[1], "Rs": x[2], "Gds": x[3],
            "Lg": x[4], "Ld": x[5], "Ls": x[6],
            "Cgp": x[7], "Cdp": x[8], "Cgd": x[9], "Cgs": x[10], "Cds": x[11]
        }
        value = calculateS.calculate_loss(parameters, 1)
        return value

    xopt, fopt,target_values = psoOptimize.pso(obj, lb, ub, maxiter=9, swarmsize=20, debug=True)
    best_values = []
    for i in range(len(target_values)):
        best_values.append(min(target_values[:i + 1]))
    return best_values

# GA有问题
def GA(pbounds):
    creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMax)
    toolbox = base.Toolbox()

    # 定义参数的随机初始化函数

    # 定义个体的初始化函数
    for i in pbounds.keys():
        toolbox.register(i, random.uniform, pbounds[i][0], pbounds[i][1])

    # 注册其他参数的生成方法

    toolbox.register("individual", tools.initCycle,
                     creator.Individual,
                     (toolbox.Rg, toolbox.Rs, toolbox.Rd,toolbox.Ls,toolbox.Ld,toolbox.Lg,toolbox.Ggsf,toolbox.Cgp,toolbox.Cdp,toolbox.Cgd,toolbox.Cgs,toolbox.Cds),
                     1)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    # 定义评估函数
    def evaluate_individual(individual):
        return objective_function(*individual),

    toolbox.register("evaluate", evaluate_individual)
    toolbox.register("mate", tools.cxTwoPoint)
    toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.1)
    toolbox.register("select", tools.selTournament, tournsize=3)

    # 执行遗传算法
    population_size = 5
    num_generations = 200

    population = toolbox.population(n=population_size)
    iteration_values = []  # 保存每次迭代的目标函数值

    for generation in range(num_generations):
        offspring = algorithms.varAnd(population, toolbox, cxpb=0.5, mutpb=0.1)
        fitnesses = list(map(toolbox.evaluate, offspring))

        for ind, fit in zip(offspring, fitnesses):
            ind.fitness.values = fit

        population = toolbox.select(offspring, k=len(population))

        best_individual = tools.selBest(population, k=1)[0]
        print(best_individual.fitness.values[0])
        iteration_values.append(-best_individual.fitness.values[0])  # 记录每次迭代的目标函数值

    target_values = iteration_values
    best_values = []
    for i in range(len(target_values)):
        best_values.append(min(target_values[:i+1]))

pbounds = {
    'Rg': (0, 50),
    'Rs': (0, 50),
    'Rd': (0, 50),
    'Ggsf': (5000, 15000),
    'Ls': (0, 100),
    'Ld': (0, 100),
    'Lg': (0, 200),
    'Cgp': (0, 1000),
    'Cdp': (0, 1000),
    'Cgd': (0, 1000),
    'Cgs': (0, 1000),
    'Cds': (0, 1000)
}

layers=[]
layers.append(Dense(6,activation='tanh'))
layers.append(Dropout(0.95))
layers.append(Dense(6))
layers.append(Scale(fixed=True,init_vals=64.0))
layers.append(CovMat(alpha_fixed=False))
opt=Adam(1e-3)

### pso
pos_values = PSO(pbounds)

### dngp
DNGP = Bayes_Optimization(objfun=obj,modeltype="DNGP",layers=layers,opt=opt,n_initial_points = 10, trial_time = 190,paras=pbounds)
chosens,loss = DNGP.optimize()


### gp
GP = Bayes_Optimization(objfun=obj,modeltype="GP",layers=layers,opt=opt,n_initial_points = 10, trial_time = 190,paras=pbounds)
chosens2,loss2 = GP.optimize()

iters = np.arange(1,len(chosens)+1,1)
best_values = []
for i in range(len(chosens)):
    best_values.append(min(loss[:i+1]))
best_values2 = []
for i in range(len(chosens)):
    best_values2.append(min(loss2[:i+1]))

plt.plot(iters,best_values,c="red")
plt.plot(iters,best_values2)
plt.plot(iters,pos_values)
plt.scatter(iters,loss)
plt.xlabel('Iteration')
plt.ylabel('Target Value')
plt.title('optimize comparation')
plt.savefig('optimize.pdf', dpi=300, bbox_inches='tight',format="pdf")
plt.legend()
plt.show()