import numpy as np
import matplotlib.pyplot as plt
import time
from Model.dknet.models import NNRegressor
from Model.dknet.layers import Dense,CovMat,Dropout,Parametrize,Scale
from Model.dknet.optimizers import Adam,SciPyMin,SDProp
from sklearn.gaussian_process import GaussianProcessClassifier,GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF,WhiteKernel,Matern,ConstantKernel as C
def f(x):
	return (x+0.5>=0)*np.sin(64*(x+0.5)**4)+np.exp(x+1)

np.random.seed(0)
x_train=np.random.random(size=(70,1))-0.5
y_train=f(x_train)+np.random.normal(0.0,0.01,size=x_train.shape)



layers=[]
layers.append(Dense(8,activation='tanh'))
layers.append(Dropout(0.99))
layers.append(Dense(8))
layers.append(Scale(fixed=True,init_vals=64.0))
layers.append(CovMat(alpha_fixed=False))
opt=Adam(1e-3)

### dkl_gp
s = time.time()
gp=NNRegressor(layers,opt=opt,batch_size=x_train.shape[0],maxiter=100,gp=True,verbose=True)
gp.fit(x_train,y_train)
x_test=np.linspace(-0.5,0.5,1000).reshape(-1,1)
#y_pred,std=gp.predict(x_test)
y_pred,std=gp.predicts(x_train,y_train,x_test)
e = time.time()
print("dkl_gp:"+str(e-s)+"s")
### general gp
s = time.time()
kernel = C(1.0, (1e-3, 1e3)) * RBF(1.0, (1e-2, 1e2))
model = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=0)

model.fit(x_train, y_train)
y_preds, sigma = model.predict(x_test, return_std=True)
e = time.time()
print("gen_gp:"+str(e-s)+"s")


plt.plot(x_train,y_train,'.')
plt.plot(x_test,f(x_test)[:,0])
plt.plot(x_test,y_pred)
plt.plot(x_test,y_preds)
plt.xlabel('X')
plt.ylabel('Y')
plt.fill_between(x_test[:,0],y_pred[:]-std,y_pred[:]+std,alpha=0.5)
plt.legend(['Training samples', 'True function', 'Predicted function',"GP",'Prediction stddev'])
plt.savefig('demo.pdf', dpi=300, bbox_inches='tight',format="pdf")
plt.show()
